<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="uiu.css">

</head>
<body class="body">
  <center>
    <h1 style="color:red;">Time Up</h1>
  </center>
   
   
    
    <div  id="myDIV">
        <center><h2 id="borderimg1" style="color:black">   
           You have lost 5 Minutes for helping her  <br>
         Your vehicle is again running after helping<br> 
         You are late to reach the class in time.....
      
        
        </h2></center>
        
        

       
    
</div>

 
<div class="container">
  <center>    
       
    <div class ="item1" style="margin-left: 500px;" >

        <div class="card">
            <img src="uiuFile/r_y_y_1_1_1.png" alt="Denim Jeans" style="width:100%;height: 50vh;">
            <h1 class="rickshaw">You are late....</h1>
           
            <form method="post" action="">
<button style="width: 85%;" class="glow-on-hover" type="submit" name="submit" class="button">PICK</button>
                                         </form>
          </div>
          
            </div>


            </center>


    </div>
        
    

         
                
                    </div>
    
</body>
</html>