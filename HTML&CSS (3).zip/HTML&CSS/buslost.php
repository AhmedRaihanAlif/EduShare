<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="uiu.css">

</head>
<body class="body">
  <center>
    <h1 style="color:greenyellow;">Time Up</h1>
  </center>
   
    <p id="demo">  </p>
    
    <div  id="myDIV">
        <center><h2 id="borderimg1">   
           You have lost 5 Minutes  <br>
         If you choose to get down it can help you to reach in time..<br>

         So,you are late to reach the class in time.....
      
        
        </h2></center>
        
        

       
    
</div>
 <center>
<div class="container">
      
       
    <div class ="item1" style="margin-left: 500px;" >

        <div class="cardss">
            <img src="uiuFile/r_y_y_1_1_1.png" alt="Denim Jeans" style="width:100%;height: 50vh;">
            <h1 class="rickshaw">You are late....</h1>
           
            <form method="get" action="helpwoman.html">
                <button type="submit" class="button">Finish</button>
            </form>
          </div>
          
            </div>





    </div>
        
           

         
                
                    </div>
                    </center>
</body>
</html>