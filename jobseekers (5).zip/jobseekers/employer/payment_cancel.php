<?php
    header("Location:http://localhost/jobseekers/employer/employer_buypackage.php?cancel_msg=Order cancel");
    exit();
?>