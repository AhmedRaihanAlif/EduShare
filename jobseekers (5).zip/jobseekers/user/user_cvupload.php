<!-- <?php
session_start();
require '../database.php';
?> -->

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CV Upload</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="../css/stylesheet.css" >     <!-- image -->
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/w3.css">
</head>
<body style=" background-color: #CCFFE5;" >

<?php
// navbar
    include 'user_navbar.php';
    //check already applied or not
?>

<?php
/*
$jobid=$_GET['jobid'];
$userid=$_SESSION['userid'];
$applysql="SELECT * FROM jobapply where userid='$userid' AND jobid='$jobid' ";
$applysqlresult=mysqli_query($connection,$applysql);
$apply_num=mysqli_num_rows($applysqlresult);

if($apply_num==1){
    header("Location:user_appliedjobview.php?apply_msg=Already applied for the job");
    exit();
}
*/
?> 
<center>
<div style="margin-top:60px;" >
 
    <label for="fname">First Name</label>
    <input type="text" id="fname" name="firstname" placeholder="Your name..">
    <br>
   
   
    <label for="fname">Last Name</label>
    <input type="text" id="fname" name="firstname" placeholder="Your name..">
    <br>  <br>
    <label for="fname">Present Address</label>
    <input type="text" id="fname" name="firstname" placeholder="Your name..">
    <br>  <br>
    <label for="fname">Salary Range</label>
    <input type="text" id="fname" name="firstname" placeholder="Your name..">
    <br>  <br>
    <label for="fname">Religion</label>
    <input type="text" id="fname" name="firstname" placeholder="Your name..">
    <br>  <br>
    <label for="country">Interested Field</label>
    <select id="country" name="country">
      <option value="australia">Graphics Designer</option>
      <option value="canada">Web Development</option>
      <option value="usa">Android Development</option>
      <option value="usa">Video Editor</option>
      <option value="usa">Photoshop Editor</option>
    </select>
    <br>   <br>
   
 
</div>

    <br>

    <div style="margin-left:25%;" class="container w3-light-yellow ">
        <div  class="row">
           <div class="col-md-8 col-md-offset-3">
                <h2 class="w3-greeen w3-padding-small" style="width: 80%;font-size:30px;color:blue;"> Upload Your CV Here </h2>
                <hr>
                <form action="user_jobapply.php" method="post" enctype="multipart/form-data">
                    <div  class="form-group">
                    <!-- <label for="job title"> job title : </label> -->
                    
                    <input class="form-control" type="file" name="cvfile" id="fileSelect">
                    <input class="form-control" type="hidden" id="jobid" name="jobid" value="<?=$jobid?>">
                    </div>
                    <button Type="submit" name="jobapply" value="jobapply" class ="btn btn-info" >Submit</button>
                <br><br>
                </form>
            </div>
        </div>
    </div>
    </center>
    <!-- <?php
        // if(isset($_GET['apply_msg'])){
        //     echo $_GET['apply_msg'];
        // }
    ?> -->

<script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>