<?php

	// Defining Constants
	define( 'HOST', 'localhost' );
	define( 'DB', 'jobseekers' );
	define( 'USER', 'root' );
	define( 'PASS', '' );
?>