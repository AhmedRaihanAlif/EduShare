<?php
    session_start();
    require '../database.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Experts View</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="../css/stylesheet.css" >     <!-- image -->
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/w3.css">
</head>
<body style="background-color:#CCFFE5 ;">

<?php
// navbar
    include 'user_navbar.php';
    // $userid=$_SESSION['userid'];
    // $sql="SELECT * from user where id='$userid' ";
    // $result=mysqli_query($connection,$sql);
    // $row=mysqli_fetch_assoc($result);
    // $image = '../images/'.$row['image'];
?>

<div style="background-color: ;">
<h3 class="w3-center">User Profile</h3>
    <div class="row">
        <div class="col-md-3 border-right">
            <div class="d-flex flex-column align-items-center text-center p-3 py-5">
                <!-- <img class="rounded-circle mt-5" width="150px" src="https://st3.depositphotos.com/15648834/17930/v/600/depositphotos_179308454-stock-illustration-unknown-person-silhouette-glasses-profile.jpg"> -->
                <form action="user_profileprocess.php" method="POST" enctype="multipart/form-data">
                <?php if(!empty($image)){?>
                <img class="rounded-circle mt-5" width="150px" src="<?=$image?>" alt="profile pic"><br><br>
                <?php }else{?>
                <input  style="margin: 0px 0px 0px 70px" type="file"id="image" name="image" accept="image/*"><br><br>
                <?php }?>
                <!-- <span class="font-weight-bold"><?= $row['name']?></span><br>
                <span class="text-black-50"><?= $row['email']?></span> -->
            </div>
        </div>
        <div class="col-md-5 border-right">
            <div class="p-3 py-5">
                <div class="row mt-2">
                    <div class="col-md-12"><label class="labels">Name</label><input  type="text" class="form-control" placeholder="Name" name="name" value=""></div>
                    <div class="col-md-12"><label class="labels">Gender</label><input  type="text" class="form-control" placeholder="Gender" name="gender" value=""></div>
                </div>
                <div class="row mt-3">
                    <div class="col-md-12"><label class="labels">Mobile Number</label><input  type="text" class="form-control" placeholder="enter phone number" name="mobile" value=""></div>
                    <div class="col-md-12"><label class="labels">Address</label><input  type="text" class="form-control" placeholder="enter address"  name="location" value=""></div>
                    <div class="col-md-12"><label class="labels">Email ID</label><input  type="email" class="form-control" placeholder="enter email id" value=""></div>
                    <div class="col-md-12"><label class="labels">Education</label><input  type="text" class="form-control" placeholder="education" name="education"  value=""></div>
                    <div class="col-md-12"><label class="labels">Skill</label><input  type="text" class="form-control" placeholder="enter skills" name="skill" value=""></div>
                    
                </div>
                <div class="mt-5 text-center"><a class="btn btn-primary" >Submit Profile</a></div>
                 </div>
        </div>
       
        <div class="col-md-4">    
            <div class="p-3 py-5">
                <div class="row mt-3">
                <div class="col-md-12"><label class="labels">Experience </label><input  type="text" class="form-control" placeholder="experience" name="experience" value=""></div> <br>
                <div class="col-md-12"><label class="labels">Additional Details</label><input  type="text" class="form-control" placeholder="additional details" name="additional" value=""></div>
            </div>
        </div>
    </form>
    </div>
</div>
</div>
</div>

<!-- <?php
if(isset($_GET['profile_update'])){
    echo $_GET['profile_update'];
}
?> -->


<script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>

