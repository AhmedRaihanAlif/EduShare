<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <a class="navbar-brand" href="employer_home.php">JobSeekers</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
  
      <ul class="navbar-nav ml-auto">
      <li class="nav-item active">
       <!--Dashboard-->
 
       
        <!--Package dashboard-->
          <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
        Post Package
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="employer_buypackage.php">Buy Package</a>
          <a class="dropdown-item" href="employer_mypackage.php">My Package</a>
       

      <!--Job Post-->
      
      <li class="nav-item">
        <a class="nav-link" href="employer_jobpost.php">Job Post</a>
      </li>

      <!--jobview-->
      <li class="nav-item">
        <a class="nav-link" href="employer_jobview.php">Job View</a>
      </li>

      <!--view application-->
      <li class="nav-item">
        <a class="nav-link" href="employer_viewapplication.php">View Application</a>
      </li>
       <!--Interview List-->
       <li class="nav-item">
        <a class="nav-link" href="employer_interviewlist.php">Interview List</a>
      </li>

      <li class="nav-item active">
      
      <a class="nav-link" href="employer_logout.php">Logout</a>
    </li>
    </ul>
  </div>
</nav>
    </ul>
  </div>
</nav>
