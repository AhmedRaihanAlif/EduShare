<?php

	// Defining Constants
	define( 'HOST', 'localhost' );
	define( 'DB', 'db0' );
	define( 'USER', 'root' );
	define( 'PASS', '' );
?>