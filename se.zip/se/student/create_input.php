<h1>Create Record</h1>



<form method=get action=create_result.php>

	dept: <input type=text name=dept> <br>

	<p>

	name: <input type=text name=name> <br>

	<p>
	nid: <input type=text name=nid> <br>

<p>
birth: <input type=text name=birth> <br>

<p>
address: <input type=text name=address> <br>

<p>

	<input type=submit value=Insert>

</form>