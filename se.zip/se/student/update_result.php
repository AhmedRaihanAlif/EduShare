<?php

    $id = $_GET["id"];

    $name = $_GET["name"];
	$nid = $_GET["nid"];

	$address = $_GET["address"];



	require_once('db_connect.php');

	$connect = mysqli_connect( HOST, USER, PASS, DB )

		or die("Can not connect");



	$query 	= "UPDATE student SET name='$name', nid='$nid',address='$address' WHERE id = $id";

	//echo $query;



	mysqli_query( $connect, $query )

		or die("Can not execute query");



	echo "<p>Record updated:<br> name = $name <br> address = $address";



	echo "<p><a href=read.php>READ all records</a>";

?>