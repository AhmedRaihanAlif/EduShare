<?php

	// Defining Constants
	define( 'HOST', 'localhost' );
	define( 'DB', 'schoolmgmt' );
	define( 'USER', 'root' );
	define( 'PASS', '' );
?>