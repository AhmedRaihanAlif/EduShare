<?php

$id = $_GET["id"];

    $name = $_GET["name"];
	$nid = $_GET["nid"];

	$address = $_GET["address"];

?>



<h1>Update Record</h1>



<form method=get action=update_result.php>



	<input type=hidden name=id value='<?php echo $id; ?>'> <br>




	name: <input type=text name=name value='<?php echo $name; ?>'>

	<p>

	nid: <input type=text name=nid value='<?php echo $nid; ?>'>

	<p>
	address: <input type=text name=address value='<?php echo $address; ?>'>

<p>

	<input type=submit value=Update>

</form>