-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 02, 2023 at 08:34 PM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 7.4.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `edushare`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `a_name` varchar(50) NOT NULL,
  `a_email` varchar(50) NOT NULL,
  `a_gender` varchar(50) NOT NULL,
  `a_password` varchar(255) NOT NULL,
  `a_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`a_name`, `a_email`, `a_gender`, `a_password`, `a_date`) VALUES
('admin2', 'admin2@gmail.com', 'male', '123456', '2022-01-12'),
('admin3', 'admin3@gmail.com', ' Female', '123456', '2022-01-28'),
('admin', 'admin@gmail.com', 'male', '123456', '2021-12-15'),
('shad', 'jhossain191254@bscse.uiu.ac.bd', ' Female', '$2y$10$1tVW/AZaiDOy9ivQNQqDVug84uYciubZHDUkDVnm2OYqe2FF9XZa6', '2022-08-10'),
('ju', 'jubayerhossen254@gmail.com', ' Female', '$2y$10$UaLJ0WV52BG5CT1HqDJA4OZzvz3s2knjN/K5l7ftImOBXtJbBAuX.', '2022-08-10'),
('shad', 'shad@gmail.com', ' Female', '123456', '2022-01-01');

-- --------------------------------------------------------

--
-- Table structure for table `after_verification`
--

CREATE TABLE `after_verification` (
  `S_no` int(11) NOT NULL,
  `uploader_name` varchar(50) NOT NULL,
  `uploader_email` varchar(50) NOT NULL,
  `teacher_name` varchar(50) NOT NULL,
  `subject` varchar(50) NOT NULL,
  `link` varchar(255) NOT NULL,
  `key` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `after_verification`
--

INSERT INTO `after_verification` (`S_no`, `uploader_name`, `uploader_email`, `teacher_name`, `subject`, `link`, `key`) VALUES
(23, 'abir', 'abirchowdhury0928@gmail.com ', 'huda sir', 'SPL', 'cQVO4jO0TMgL4Zup3zMBOQwM3eFHxaRCfrYRanuTx5UXOHoM3u5MJ8Ui4MJcTD7VOYd2oH6IRPkS2Cw5hQnnlwY1wocwZLGmshGofVkohXCI5dIetJ8LfXN0OaA8yEeX', 459660554),
(24, 'abir', 'abirchowdhury0928@gmail.com ', 'huda sir', 'SPL', 't9mrjnGLZGUw9DW7PHaW5GYET2oUi5Ilwp32bkAO0tBc4MDkM1kMf2bIq22Qqdwc86N0gJ09DGzkmW14FqN1+1IfyusbPX1x9gxyeGLcYGCV7ADrzujp6HkJqJnDHhut', 1191429256),
(25, 'abir', 'abirchowdhury0928@gmail.com ', 'abir', 'OOP', '199mV9wrh1469R7AsT3hZelkFF2IhwTrIkxywrRBTPduYJCnt/ogYJjA1kmNjvsHN3Imyi8FNVoL3nz7R7WlrDa6616Xn1MplKFEjR3tv7LaNXpxVIdA9PmatRBecEuC', 742980230);

-- --------------------------------------------------------

--
-- Table structure for table `ans_before_varification`
--

CREATE TABLE `ans_before_varification` (
  `S_no` int(11) NOT NULL,
  `qs_id` int(11) NOT NULL,
  `qs` varchar(255) NOT NULL,
  `ans_name` varchar(25) NOT NULL,
  `ans` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `ans_before_varification`
--

INSERT INTO `ans_before_varification` (`S_no`, `qs_id`, `qs`, `ans_name`, `ans`) VALUES
(8, 1, 'sfad', 'abir', 'sdf');

-- --------------------------------------------------------

--
-- Table structure for table `before_verification`
--

CREATE TABLE `before_verification` (
  `S_no` int(11) NOT NULL,
  `uploader_name` varchar(50) NOT NULL,
  `uploader_email` varchar(50) NOT NULL,
  `teacher_name` varchar(50) NOT NULL,
  `subject` varchar(50) NOT NULL,
  `link` varchar(600) NOT NULL,
  `key` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `carrier`
--

CREATE TABLE `carrier` (
  `no` int(11) NOT NULL,
  `uploder_name` varchar(50) NOT NULL,
  `topic` varchar(100) NOT NULL,
  `heading` varchar(100) NOT NULL,
  `details` varchar(10000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `carrier`
--

INSERT INTO `carrier` (`no`, `uploder_name`, `topic`, `heading`, `details`) VALUES
(1, 'fsda', 'sdf', 'afds', 'df'),
(2, 'fds', 'fsd', 'sfa', 'sdf'),
(3, 'abir', 'math', 'matrix', 'like 2d array'),
(4, 'Jubayer Hossen', 'CSE', 'What Can You Do With A Computer Science Degree?', 'If you’ve studied computer science, you will have gained many technical and non-technical skills which are highly valued by employers, from leadership to programming.  The increasing scope of computer science means you have plenty of choice in a wide variety of highly specialized areas. \r\n\r\nComputer technologies are integral to modern life, so you’re likely to find your computer science skills in high demand across many different industries. These include financial organizations, management consultancy firms, software houses, communications companies, data warehouses, multinational companies, governmental agencies, universities and hospitals. \r\n\r\nAs always, it’s extremely beneficial to have completed relevant work experience. You should also consider compiling a portfolio of your own independent projects outside of your degree, which could be in the form of programming, moderating online or even building an app. This will demonstrate to employers your interest in the subject and your problem-solving skills, creativity and initiative.\r\n\r\nWorking in partnership with clients, an IT consultant advises clients on the planning, design, installation and usage of information technology systems to meet their business objectives, overcome problems or improve the structure and efficiency of their IT systems.\r\n\r\nAs you represent a broad role in IT, your job will be similar to that of systems analysts, systems designers and applications programmers, whose roles are more specialized but nonetheless work on a consultancy basis.\r\n\r\nYou may also become involved in sales and business development, identifying potential clients and maintaining good business contacts. There is fierce competition in this role, so gaining work experience in a commercial environment would help increase your prospects.'),
(5, 'Jubayer Hossen', 'EEE', 'What is EEE?', 'fbhsdbjkfnsjkdmflksm mkoksmfoksdlfdskfffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffdslf sopdkfiojskdiofjisod idjsfiojsidofjk sdjkfiopsdopfksodkfopskdopfksopdkf osdkfops dopfksopkfopskdopfksopdkfops dfo kiosdfiojiosdjfiojs ijfiosjdfiosjdiofjsiojfiosdj fsdjkfiopskdopfksopdf iojf iojsdof sdof ops kfsdkfopopsdofl'),
(6, 'fs', 'sd', 'sfa', 'dfsf'),
(7, 'abir', 'oop', 'interface', 'fdsafsdaf'),
(8, 'abir', 'spl', 'for', 'dsagsafds');

-- --------------------------------------------------------

--
-- Table structure for table `quize`
--

CREATE TABLE `quize` (
  `S_no` int(11) NOT NULL,
  `course` varchar(50) NOT NULL,
  `topic` varchar(50) NOT NULL,
  `link` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `quize`
--

INSERT INTO `quize` (`S_no`, `course`, `topic`, `link`) VALUES
(2, 'spl', 'for loop', 'https://docs.google.com/forms/d/16ynfrN1z_DzU4SOHZ4GEhJMlckzH5D03CIWqp5EYiMI/edit'),
(3, 'oop', 'arraylist', 'https://docs.google.com/forms/d/16ynfrN1z_DzU4SOHZ4GEhJMlckzH5D03CIWqp5EYiMI/edit'),
(4, 'sad', 'diagram', 'https://docs.google.com/forms/d/1n2aYerNowg5u88lSjudkLOiEgGPe1w3a4sA8KHh5O_Q/edit'),
(6, 'Math', 'Matrix', 'https://forms.gle/3j3vcJY9gaznJYCi8'),
(7, 'fdsa', 'sfd', 'asfd'),
(8, 'fdsa', 'sfd', 'asfd');

-- --------------------------------------------------------

--
-- Table structure for table `req_qs`
--

CREATE TABLE `req_qs` (
  `S_no` int(11) NOT NULL,
  `User_name` varchar(255) NOT NULL,
  `user_email` varchar(255) NOT NULL,
  `qs` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `req_qs_accept`
--

CREATE TABLE `req_qs_accept` (
  `S_no` int(11) NOT NULL,
  `User_name` varchar(255) NOT NULL,
  `user_email` varchar(255) NOT NULL,
  `qs` varchar(255) NOT NULL,
  `ans_name` varchar(50) NOT NULL,
  `ans` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `req_qs_accept`
--

INSERT INTO `req_qs_accept` (`S_no`, `User_name`, `user_email`, `qs`, `ans_name`, `ans`) VALUES
(2, 'Abir Chowdhury', 'abir@gmail.com', 'what is php?\r\n                                            ', 'abir', 'PHP is a widely-used, open source scripting language '),
(19, 'Abir Chowdhury', 'abir@gmail.com', 'what is php?\r\n                                            ', 'None', 'None'),
(29, 'shad', 'afdsf', 'html', 'Abir Chowdhury', 'language'),
(30, 'chowdhury', 'fsajfa', 'java', 'Abir Chowdhury', 'progamming'),
(31, 'shad', 'afdsf', 'html', 'Abir Chowdhury', 'hypertxt'),
(32, 'shad', 'afdsf', 'html', 'Abir Chowdhury', 'language'),
(33, 'shad', 'afdsf', 'html', 'Abir Chowdhury', 'hypertxt'),
(34, 'chowdhury', 'fsajfa', 'java', 'Abir Chowdhury', 'progamming'),
(35, 'Abir Chowdhury', 'abir@gmail.com', 'what is php?\r\n                                            ', 'Abir Chowdhury', 'is a language'),
(36, 'Abir Chowdhury', 'abir@gmail.com', 'what is php?\r\n                                            ', 'Abir Chowdhury', 'is a website'),
(37, 'Abir Chowdhury', 'abir@gmail.com', 'what is math?\r\n                                            ', 'Abir Chowdhury', 'math is very hard'),
(38, 'Abir Chowdhury', 'abir@gmail.com', 'what is math?\r\n                                            ', 'Abir Chowdhury', 'math is nice'),
(39, 'Abir Chowdhury', 'abir@gmail.com', 'what is oop?\r\n                                            ', 'Abir Chowdhury', 'progrem'),
(40, 'shad', 'a@gmail.com', 'what is biology?', 'shad', 'xyz'),
(41, 'Abir Chowdhury', 'abir@gmail.com', '\r\n dfsa                                           ', 'Abir Chowdhury', 'fsdafd'),
(42, 'Abir Chowdhury', 'abir@gmail.com', ' dfsa                                           ', 'Abir Chowdhury', 'ss'),
(43, 'Abir Chowdhury', 'abir@gmail.com', 'fdsfas\r\n                                            ', 'Abir Chowdhury', 'sdfsad'),
(44, 'Abir Chowdhury', 'abir@gmail.com', 'fdsfas\r\n                                            ', 'Abir Chowdhury', 'fdsaf');

-- --------------------------------------------------------

--
-- Table structure for table `track`
--

CREATE TABLE `track` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `gender` varchar(11) NOT NULL,
  `status` varchar(11) NOT NULL,
  `work` varchar(100) NOT NULL,
  `time` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `track`
--

INSERT INTO `track` (`id`, `name`, `email`, `gender`, `status`, `work`, `time`) VALUES
(119, 'Chowdhury', 'c@gmail.com', 'male', 'BLOCKED', 'Logs in the system', '2022-08-04 18:28:35'),
(120, 'Chowdhury', 'c@gmail.com', 'male', 'BLOCKED', 'Logs out the system', '2022-08-04 18:28:39'),
(121, 'Chowdhury', 'c@gmail.com', 'male', 'BLOCKED', 'Logs in the system', '2022-08-04 18:29:05'),
(122, 'Chowdhury', 'c@gmail.com', 'male', 'BLOCKED', 'Cleck on carriar gideline', '2022-08-04 18:29:08'),
(123, 'Chowdhury', 'c@gmail.com', 'male', 'BLOCKED', 'Check on feedback', '2022-08-04 18:29:09'),
(124, 'Chowdhury', 'c@gmail.com', 'male', 'BLOCKED', 'Cleck on quize', '2022-08-04 18:29:14'),
(125, 'Chowdhury', 'c@gmail.com', 'male', 'BLOCKED', 'Logs out the system', '2022-08-04 18:29:14'),
(126, 'user', 'user@gmail.com', 'male', 'BLOCKED', 'Logs in the system', '2022-08-04 18:29:19'),
(127, 'user', 'user@gmail.com', 'male', 'BLOCKED', 'Cleck on carriar gideline', '2022-08-04 18:29:21'),
(128, 'user', 'user@gmail.com', 'male', 'BLOCKED', 'Check on feedback', '2022-08-04 18:29:23'),
(129, 'user', 'user@gmail.com', 'male', 'BLOCKED', 'Cleck on upload', '2022-08-04 18:29:24'),
(130, 'user', 'user@gmail.com', 'male', 'BLOCKED', 'Logs out the system', '2022-08-04 18:29:27'),
(131, 'shad', 'a@gmail.com', 'Female', 'ACTIVE', 'Logs in the system', '2022-08-04 18:29:30'),
(132, 'shad', 'a@gmail.com', 'Female', 'ACTIVE', 'Cleck on quize', '2022-08-04 18:29:31'),
(133, 'shad', 'a@gmail.com', 'Female', 'ACTIVE', 'Check on feedback', '2022-08-04 18:29:34'),
(134, 'shad', 'a@gmail.com', 'Female', 'ACTIVE', 'Logs out the system', '2022-08-04 18:29:36'),
(135, 'Chowdhury', 'c@gmail.com', 'male', 'BLOCKED', 'Logs in the system', '2022-08-04 18:30:13'),
(136, 'Chowdhury', 'c@gmail.com', 'male', 'BLOCKED', 'Logs out the system', '2022-08-04 18:30:16'),
(137, 'shad', 'a@gmail.com', 'Female', 'ACTIVE', 'Logs in the system', '2022-08-04 18:30:41'),
(138, 'abc', 'abc@gmail.com', 'male', 'BLOCKED', 'Logs in the system', '2022-09-20 21:34:31'),
(139, 'abc', 'abc@gmail.com', 'male', 'BLOCKED', 'Logs out the system', '2022-09-20 21:35:18'),
(140, '', 'admin@gmail.com', '', 'ACTIVE', 'Logs out the system', '2022-09-20 21:36:51'),
(141, 'abc', 'abc@gmail.com', 'male', 'BLOCKED', 'Logs in the system', '2022-09-20 21:37:00'),
(142, 'abc', 'abc@gmail.com', 'male', 'BLOCKED', 'Cleck on carriar gideline', '2022-09-20 21:37:09'),
(143, 'abc', 'abc@gmail.com', 'male', 'BLOCKED', 'Check on feedback', '2022-09-20 21:37:10'),
(144, 'abc', 'abc@gmail.com', 'male', 'BLOCKED', 'Cleck on upload', '2022-09-20 21:37:10'),
(145, 'abc', 'abc@gmail.com', 'male', 'BLOCKED', 'Cleck on quize', '2022-09-20 21:37:11'),
(146, 'abc', 'abc@gmail.com', 'male', 'BLOCKED', 'Logs out the system', '2022-09-20 21:37:14'),
(147, 'abc', 'abc@gmail.com', 'male', 'BLOCKED', 'Logs in the system', '2022-09-20 21:44:55'),
(148, 'abc', 'abc@gmail.com', 'male', 'BLOCKED', 'Cleck on carriar gideline', '2022-09-20 21:44:59'),
(149, 'abc', 'abc@gmail.com', 'male', 'BLOCKED', 'Check on feedback', '2022-09-20 21:45:18'),
(150, 'abc', 'abc@gmail.com', 'male', 'BLOCKED', 'Cleck on upload', '2022-09-20 21:45:18'),
(151, 'abc', 'abc@gmail.com', 'male', 'BLOCKED', 'Cleck on quize', '2022-09-20 21:45:19'),
(152, 'abc', 'abc@gmail.com', 'male', 'BLOCKED', 'Logs out the system', '2022-09-20 21:45:20');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `u_name` varchar(50) NOT NULL,
  `u_email` varchar(50) NOT NULL,
  `u_gender` varchar(50) NOT NULL,
  `u_password` varchar(255) NOT NULL,
  `date` date NOT NULL,
  `active` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`u_name`, `u_email`, `u_gender`, `u_password`, `date`, `active`) VALUES
('a', 'a@gmail.com', 'Male', '$2y$10$IMJL6/XO7aVmhxE2Sw6ZUOPUelUa46vM33bm1rprWaDba1y0yR/cm', '2022-09-21', ''),
('abc', 'abc@gmail.com', 'male', '123456', '2022-09-22', 'BLOCKED'),
('abir', 'abir@gmai.com', 'male', '123456', '2022-09-14', 'ACTIVE'),
('abir', 'abirchowdhury0928@gmail.com', 'Male', '$2y$10$pEDEb4pZeE81IH/fb1BCJ.RnQdf.EMyJ7eMtt4/nuuuC4VXn8KfQG', '2022-08-18', ''),
('pias', 'piasahammed47@gmail.com', 'Male', '$2y$10$gxLrMJ2upH8DpRdsSl377eNHomvsZBwL2tx88bpRRePeLcdccFbYa', '2022-08-03', ''),
('rakib ', 'rakib@gmail.com', 'Male', '$2y$10$SwA5w30H.lbQpIPYK7Fdj.CwbEAFqBwARv3l.8kBHprLwIHyXuCPe', '2022-09-22', ''),
('Shad', 'Shad@gmail.com', 'Male', '$2y$10$83De34hrMuDGAf/91.yqn.KrfcLcxMLDrpM6lVM2Ypl4GvMHbY6FC', '2022-09-16', ''),
('xyz', 'xyz@gmail.com', 'Male', '$2y$10$2Vhl2qZi8b42clwQW4p/NOj4EIjG0YOEUU/5eAUoclI6bbVDV.dpi', '2022-09-15', '');

-- --------------------------------------------------------

--
-- Table structure for table `user_feedback`
--

CREATE TABLE `user_feedback` (
  `S_no` int(11) NOT NULL,
  `user_name` varchar(50) NOT NULL,
  `u_email` varchar(50) NOT NULL,
  `feedback` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user_feedback`
--

INSERT INTO `user_feedback` (`S_no`, `user_name`, `u_email`, `feedback`) VALUES
(1, 'abir', 'user@gmail.com', 'good work'),
(3, 'Shad', 'user@gmail.com', 'improve UI'),
(5, 'Abir Chowdhury', 'abir@gmail.com', 'show mark on quiz\r\n                                            '),
(9, 'Abir Chowdhury', 'abir@gmail.com', 'dfsafk\r\n                                            '),
(10, 'shad', 'a@gmail.com', 'This is very good website\r\n                                            ');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`a_email`);

--
-- Indexes for table `after_verification`
--
ALTER TABLE `after_verification`
  ADD PRIMARY KEY (`S_no`);

--
-- Indexes for table `ans_before_varification`
--
ALTER TABLE `ans_before_varification`
  ADD PRIMARY KEY (`S_no`);

--
-- Indexes for table `before_verification`
--
ALTER TABLE `before_verification`
  ADD PRIMARY KEY (`S_no`);

--
-- Indexes for table `carrier`
--
ALTER TABLE `carrier`
  ADD PRIMARY KEY (`no`);

--
-- Indexes for table `quize`
--
ALTER TABLE `quize`
  ADD PRIMARY KEY (`S_no`);

--
-- Indexes for table `req_qs`
--
ALTER TABLE `req_qs`
  ADD PRIMARY KEY (`S_no`);

--
-- Indexes for table `req_qs_accept`
--
ALTER TABLE `req_qs_accept`
  ADD PRIMARY KEY (`S_no`);

--
-- Indexes for table `track`
--
ALTER TABLE `track`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`u_email`);

--
-- Indexes for table `user_feedback`
--
ALTER TABLE `user_feedback`
  ADD PRIMARY KEY (`S_no`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `after_verification`
--
ALTER TABLE `after_verification`
  MODIFY `S_no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `ans_before_varification`
--
ALTER TABLE `ans_before_varification`
  MODIFY `S_no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `before_verification`
--
ALTER TABLE `before_verification`
  MODIFY `S_no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `carrier`
--
ALTER TABLE `carrier`
  MODIFY `no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `quize`
--
ALTER TABLE `quize`
  MODIFY `S_no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `req_qs`
--
ALTER TABLE `req_qs`
  MODIFY `S_no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `req_qs_accept`
--
ALTER TABLE `req_qs_accept`
  MODIFY `S_no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- AUTO_INCREMENT for table `track`
--
ALTER TABLE `track`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=153;

--
-- AUTO_INCREMENT for table `user_feedback`
--
ALTER TABLE `user_feedback`
  MODIFY `S_no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
