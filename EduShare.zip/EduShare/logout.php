<?php
    session_start();
    include '_dbconnect.php';
    $email = $_SESSION['email'];
    $u_name = $_SESSION['name'];

    $sql = "INSERT INTO `log`(`name`, `email`, `activity`, `time`) VALUES ('$u_name','$email','Logs Out',NOW())";
    $result = mysqli_query($con,$sql);
    
    session_destroy();
    header('location:index.html');
?>