<?php
   $name="<u>John</u>";
   $lastName= "Travolta";
   $name .= ": ";
   $a =  $name." ".$lastName;

    echo $a;
?>