<?php
  session_start();
  $a_auth = $_SESSION['a_auth'];
  if($a_auth==null){
    header('Location:index.html');
    
  }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js" integrity="sha512-894YE6QWD5I59HgZOGReFYm4dnWc1Qt5NtvYSaNcOP+u1T9qYdvdihz0PPSiiqn/+/3e7Jo4EaG7TubfWGUrMQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>


    <!-- bootstrap cdn -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KyZXEAg3QhqLMpG8r+8fhAXLRk2vvoC2f3B09zVXn8CA5QIVfZOJ3BCsw2P0p/We" crossorigin="anonymous">
    <!-- font awsome cdn  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" integrity="sha512-1ycn6IcaQQ40/MKBW2W4Rhis/DbILU74C1vSrLJxCq57o941Ym01SwNsOMqvEBFlcgUa6xLiPY/NS5R+E6ztJQ==" crossorigin="anonymous" referrerpolicy="no-referrer"
    />
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/admin.css">
    <title>Admin Home</title>
</head>
<body>

    <section class="navbar_bg">
        <nav class="navbar navbar-expand-lg navbar-light ">
            <div class="container ">
                <a class="navbar-brand" href="adminhome.php"><img src="images/logo_written.png" alt=""></a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                  </button>
                <div class="collapse navbar-collapse" id="navbarNavDropdown">
                    <ul class="navbar-nav ms-auto text-center">
                        <li class="nav-item">
                            <a class="nav-link " aria-current="page" href="adminhome.php">Home</a>
                        </li>
                       
                        <li class="nav-item">
                            <a class="nav-link" href="create_admin.php">Create Admin</a>
                        </li>
                   
                        <li class="nav-item">
                            <a class="nav-link " href="logout.php">Logout</a>
                        </li>

                    </ul>
                </div>
            </div>
        </nav>
    </section>
    <div class="gap">
        <div class="button">
            <a class="btn-grad-1" href="requestedfile.php">file approval</a>
            <a class="btn-grad-2" href="https://dashboard.tawk.to/#/dashboard/61c895ea80b2296cfdd3db1a">live chat</a>
            <a class="btn-grad-4" href="view_feedback.php">view feedback</a>
            <a class="btn-grad-1" href="backup.php">Backup Database</a>
            
        </div>
    <div class="button">
            
            <a class="btn-grad-3" href="https://docs.google.com/forms/u/0/?fbclid=IwAR1cA6OxBrNr4wQ3CTNs1pQ2UM6NeV0zICnzDXGJccYqVKPFeFlZb2wI8gg&tgif=d">Create Question link</a>
            <a class="btn-grad-1" href="creat_quize.php">Submit Question Link</a>
            <a class="btn-grad-4" href="log.php">View Log</a>
            
        </div>
        </div>
    
     
    
   
   
    
  
  
 
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="style.js"></script>
   
</body>
</html>