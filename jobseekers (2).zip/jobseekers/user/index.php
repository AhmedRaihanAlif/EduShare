<?php
header('Location: user_login.php');
exit;
?>