<?php

	// Defining Constants
	define( 'HOST', 'localhost' );
	define( 'DB', 'scholarship' );
	define( 'USER', 'root' );
	define( 'PASS', '' );
?>
