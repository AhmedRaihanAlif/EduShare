<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}

.topnav {
  overflow: hidden;
  background-color: #e55300;
  padding-top:20px;
}

.topnav a {
  float: left;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}

.topnav a.active {
  background-color: #04AA6D;
  color: white;
}

.topnav-right {
  float: right;
}

.header {
  background-color:red ;
  color: #ffffff;
  padding: 15px;
  margin-bottom:10px;
}

.footer {
  background-color: #198754;
  color: #ffffff;
  text-align: center;
  font-size: 12px;
  padding: 15px;
  padding-right:130px;
  padding-top:10px;
}
</style>
</head>
<body style="background-color: #198754;">
<style>
    * {
           margin-top:5px;
           padding-left:2px;
           padding-right:2px;
           font-family:sans-serif;
         
    }
    .background-image {
      background-image:url('https://thumbs.dreamstime.com/b/getting-school-scholarship-written-chalkboard-chalk-65790596.jpg');
      background-size:cover;
      background-repeat:no-repeat;
      height:60vh;
    }
   

    
  </style>
  <div class="header">
  <h1 style="margin-left:800px">ScholarWorld.com</h1>
</div>
    

<div class="topnav">
  <a style="margin-right:40px; color:lime"  href="dash.php">Home</a>
  <a style="margin-right:40px" href="post_delete.php">Delete/Edit Post</a>
  <a style="margin-right:40px" href="deletestudentdetails.php">Delete/Edit Student Details</a>
  <a style="margin-right:40px" href="edulistdelete.php">Delete/Edit Education List</a>
  <a style="margin-right:40px" href="unidetailsdelete.php">Delete/Edit University List</a>
  <a style="margin-right:40px" href="modreq.php">Delete/Edit Moderator Request</a>
  

</div>

<div class="background-image" >

</div>





<div class="footer">
  <h1>We Try To Give You A Easy Way To Go To Abroad !!!</h1>
</div>

</body>
</html>
