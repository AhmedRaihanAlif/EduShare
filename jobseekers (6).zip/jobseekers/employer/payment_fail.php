<?php
    header("Location:http://localhost/jobseekers/employer/employer_buypackage.php?fail_msg=Payment Failed");
    exit();
?>