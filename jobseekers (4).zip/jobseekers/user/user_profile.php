

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Applied Jobs View</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="../css/stylesheet.css" >     <!-- image -->
    <link rel="stylesheet" href="../css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/w3.css">
</head>
<body class=" w3-pale-yellow">

<?php
// navbar
    include 'user_navbar.php';
    // $userid=$_SESSION['userid'];
    // $sql="SELECT * from user where id='$userid' ";
    // $result=mysqli_query($connection,$sql);
    // $row=mysqli_fetch_assoc($result);
    // $image = '../images/'.$row['image'];
?>

<div class="container rounded bg-white mt-5 mb-5 w3-card-4 w3-light-blue">
<h3 class="w3-center">User Profile</h3>
    <div class="row">
        <div class="col-md-3 border-right">
            <div class="d-flex flex-column align-items-center text-center p-3 py-5">
                <!-- <img class="rounded-circle mt-5" width="150px" src="https://st3.depositphotos.com/15648834/17930/v/600/depositphotos_179308454-stock-illustration-unknown-person-silhouette-glasses-profile.jpg"> -->
                <form action="user_profileprocess.php" method="POST" enctype="multipart/form-data">
                <?php if(!empty($image)){?>
                <img class="rounded-circle mt-5" width="150px" src="<?=$image?>" alt="profile pic"><br><br>
                <?php }else{?>
                <input  style="margin: 0px 0px 0px 70px" type="file"id="image" name="image" accept="image/*"><br><br>
                <?php }?>
                <!-- <span class="font-weight-bold"><?= $row['name']?></span><br>
                <span class="text-black-50"><?= $row['email']?></span> -->
            </div>
        </div>

        <?php
		require_once("dbconnect.php");
		$connect = mysqli_connect( HOST, USER, PASS, DB )
			or die("Can not connect");


		$results = mysqli_query( $connect, "SELECT name,companyname,location,email,mobile,position,experience,additional FROM `employer` where name ='Minhajul Islam' " )
			or die("Can not execute query");
	?>
    <?php
    while( $rows = mysqli_fetch_array( $results ) ) {
        extract( $rows );
        ?>

        <div class="col-md-5 border-right">
            <div class="p-3 py-5">
                <div class="row mt-2">
                    <div class="col-md-12"><label class="labels">Name</label><input  type="text" class="form-control"  name="name" value="<?= $rows['name']?>"></div>
                    <div class="col-md-12"><label class="labels">companyname</label><input  type="text" class="form-control" placeholder="Gender" name="company" value="<?= $rows['companyname']?>"></div>
                </div>
                <div class="rows mt-3">
                    <div class="col-md-12"><label class="labels">location</label><input  type="text" class="form-control" name="location" value="<?= $rows['location']?>"></div>
                    <div class="col-md-12"><label class="labels">email</label><input  type="text" class="form-control"   name="email" value="<?= $rows['email']?>"></div>
                    <div class="col-md-12"><label class="labels">mobile</label><input  type="email" class="form-control" name="mobile" value="<?= $rows['mobile']?>"></div>
                    <div class="col-md-12"><label class="labels">position</label><input  type="text" class="form-control" name="position"  value="<?= $rows['position']?>"></div>

                    
                </div>
                
 
                <!-- <div class="mt-5 input-center"><a class="btn btn-primary" href=user_profileedit.php?profileupdate=profileupdate"> Profile</a></div> -->
                 </div>
        </div>
       
        <div class="col-md-4">    
            <div class="p-3 py-5">
                <div class="rows mt-3">
                <div class="col-md-12"><label class="labels">Experience </label><input  type="text" class="form-control"  name="experiences" value="<?= $rows['experience']?>"></div> <br>
                <div class="col-md-12"><label class="labels">Additional Details</label><input  type="text" class="form-control"  name="additionals" value="<?= $rows['additional']?>"></div>
            </div>
        </div>
    </form>
    </div>
    <?php
    }
    ?>
</div>
</div>
</div>


<script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>

