<nav class="navbar navbar-expand-lg " style="">
  <a class="navbar-brand" href="user_home.php">SkillTutor</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
  
      <ul class="navbar-nav ml-auto">
      <li class="nav-item active">
       <!--Dashboard-->
        
      <!--User Profile-->
      
      <li class="nav-item">
        <a class="nav-link" href="user_profile.php">Profile</a>
      </li>

      

      <!--View Applied Job-->
      <li class="nav-item">
        <a class="nav-link" href="user_appliedjobview.php">Notifications</a>
      </li>
      
       <!--Interview List-->
       <li class="nav-item">
        <a class="nav-link" href="user_interviewschedule.php">Become Experts</a>
      </li>

      <li class="nav-item">
        <a class="nav-link" href="user_interviewschedule.php">View Skill</a>
      </li>

      <!--Interview List-->
      <li class="nav-item">
        <a class="nav-link" href="user_interviewtips.php"></a>
      </li>


      <li class="nav-item active">
      
      <a class="nav-link" href="user_logout.php">Logout</a>
    </li>
    </ul>
  </div>
</nav>
    </ul>
  </div>
</nav>
