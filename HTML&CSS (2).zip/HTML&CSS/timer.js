var deadline = new Date("Sept 6, 2022 05:30").getTime();
var x = setInterval(function() {
var now = new Date().getTime();
var t = deadline - now;

var minutes = Math.floor((t % (1000 * 60 * 60)) / (1000 * 60));
var seconds = Math.floor((t % (1000 * 60)) / 1000);
document.getElementById("demo").innerHTML =  
 minutes + "m " + seconds + "s ";
    if (t < 0) {
        clearInterval(x);
        document.getElementById("demo").innerHTML = "EXPIRED";
    }
}, 1000);