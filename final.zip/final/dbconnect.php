<?php


	define( 'HOST', 'localhost' );
	define( 'DB', 'scholarship' );
	define( 'USER', 'root' );
	define( 'PASS', '' );
?>
