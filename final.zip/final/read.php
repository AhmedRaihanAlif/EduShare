<!DOCTYPE html>
<html>
<head> 
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Reading from DB</title>
	<link  rel="stylesheet" href="read.css">
</head>
<body style="background-color: #198754;">
<style>
		


#customers {

font-family: Arial, Helvetica, sans-serif;
border-collapse: collapse;
width: 90vh;
height: 40vh;
border-radius: 15px;

}

#customers td, #customers th {


border-radius: 15px;
padding: 15px;
}

#customers tr:nth-child(even){background-color: lightcyan;}
#customers tr:nth-child(odd){background-color: lightgrey;}

#customers tr:hover {background-color: rosybrown;}

#customers th {
padding-top: 12px;
padding-bottom: 12px;
text-align: left;
background-color:lightgoldenrodyellow;
color: brown;
font-size: 25px;
}

    
</style>

<div class="main">
    <center>
<div class="header">
  <h1 style="margin-bottom:50px;">Reading From DB</h1>
</div>
	<?php
		require_once("dbconnect.php");
		$connect = mysqli_connect( HOST, USER, PASS, DB )
			or die("Can not connect");


		$results = mysqli_query( $connect, "SELECT serial_number,university_name,catagory_name,post_date,post_session,deadline from scholarship_posts ")
			or die("Can not execute query");
	?>



	


<table id='customers'> 
	  <th>University Name</th>
      <th>Catagory Name</th>  
      <th>Post Date</th> 
      <th>Post Session</th> 
      <th>Deadline</th> 
      <th>Action</th>
	  <?php
	  while( $rows = mysqli_fetch_array( $results ) ) {
				extract( $rows );
                $serial_number=$rows['serial_number'];
				
                $university_name=$rows['university_name'];
                $catagory_name=$rows['catagory_name'];
                $post_date=$rows['post_date'];
               
                $post_session=$rows['post_session'];
                $deadline=$rows['deadline'];
            
                 
				?>
			<tr>
				
       <td> <?php echo $university_name  ?>  </td>
	   <td> <?php echo $catagory_name ?> </td>	
	   <td> <?php echo $post_date  ?></td>
	   <td> <?php echo $post_session  ?></td>
       <td> <?php echo $deadline ?></td>
       <td> <a href="update.php?serial_number=<?php echo $serial_number?>" >Edit </a> 
		    <a href="delete.php?serial_number=<?php echo $serial_number ?>">Delete</a>
       </td> 
	
		
	    </tr> 
		
		
		 <?php	
			}
      ?>

			</table>
		

  
</table>
	
</center>



    
    

</body>
</html>

