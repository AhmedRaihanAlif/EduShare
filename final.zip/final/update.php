<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body style="background-color: #198754;">

<?php

require_once('dbconnect.php');
		$connect = mysqli_connect( HOST, USER, PASS, DB )
			or die("Can not connect");

            if(!$connect){
                die("Not Connected" .mysqli_error());
              }  

              if( isset($_REQUEST['serial_number'])){
              $recv=$_REQUEST['serial_number'];
              $query="SELECT university_name,catagory_name,post_date,post_session,deadline
              FROM scholarship_posts 
              where serial_number=$recv";
              $results=mysqli_query($connect,$query);



              while( $rows = mysqli_fetch_array( $results ) ) {
				
                ?>
				
				<form class="ui form"  action="updates.php" method="post"   >
			University Name: <input type="text" name="university_name" value="<?php echo $rows['university_name'] ?>"> <br>

			<p>

           Catagory Name: <input type="text" name="catagory_name" value="<?php echo $rows['catagory_name'] ?>"> <br>

            <p>

			Post Date: <input type="text" name="post_date" value="<?php echo $rows['post_date'] ?>"> <br>

			<p>

			

			Post Session: <input type="text" name="post_session" value="<?php echo $rows['post_session'] ?>"> <br>

			<p>
            Deadline: <input type="text" name="deadline" value="<?php echo $rows['deadline'] ?>"> <br>

			<p>
                <input type="hidden" name="hidden" value="<?php echo $recv; ?>">

			<input class="ui big right floated blue button" type="submit" name="submit" value="Update ">

		</form>
        <?php
			}
        }
        
        
?>



</body>
</html>

