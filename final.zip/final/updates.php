<?php

require_once('dbconnect.php');
		$connect = mysqli_connect( HOST, USER, PASS, DB )
			or die("Can not connect");

            if(!$connect){
                die("Not Connected" .mysqli_error());
              } 

              if(isset($_REQUEST['submit'])){
                $university_name = $_REQUEST["university_name"];
                $catagory_name =$_REQUEST["catagory_name"];
                $post_date = $_REQUEST["post_date"];
                
                $post_session = $_REQUEST["post_session"];
                $deadline = $_REQUEST["deadline"];
                $hidden = $_REQUEST["hidden"];
              
              
              $update_query="UPDATE scholarship_posts SET university_name='$university_name',catagory_name='$catagory_name',
             post_date='$post_date',post_session='$post_session',deadline='$deadline'where serial_number=$hidden;";

             $result = mysqli_query($connect,$update_query);
              }
 
if($result){
    header("location: read.php?Updated");
} 






      
              

?>
