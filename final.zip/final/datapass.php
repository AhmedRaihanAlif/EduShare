<?php
session_start();
if(isset($_POST['username']) && isset($_POST['psw'])){


  require_once("dbconnect.php");
      $connect = mysqli_connect( HOST, USER, PASS, DB )
          or die("Can not connect");



  $username =mysqli_real_escape_string($connect,$_REQUEST['username']);
  $psw =mysqli_real_escape_string($connect,$_REQUEST['psw']);



          $query="SELECT username,password
          FROM uiuexpresslogin 
          where username='$username' AND password ='$psw';";
          

      $result=mysqli_query($connect,$query);

      $mysql=mysqli_num_rows($result);

      if($mysql){
        
        
         
          $_SESSION['user']=$username;
         
          $url="home.php?"; 
          
          
          
         // $username=$_POST['username'];
        // $url="home.php?username=".$username;
        header('location: '.$url);
        
      }
      else{
          header("location: type3.html?Login Cancel");
      }
      }
?>

<?php

session_start();

echo $_SESSION['user'];

if(isset($_POST['submit'])){
  
  $username=$_SESSION['user'];
  $url="uiu.php?";
  header('location: '.$url);
}
   
   
      if(isset($_POST['submit2'])){
        $username=$_GET['username'];
      
        $url="jungleHome.php?username=".$username;
      header('location: '.$url);
      }
   
   



?>

---------------------------------------------------------



<?php

if(isset($_POST['username']) && isset($_POST['psw'])){


  require_once("dbconnect.php");
      $connect = mysqli_connect( HOST, USER, PASS, DB )
          or die("Can not connect");



  $username =mysqli_real_escape_string($connect,$_REQUEST['username']);
  $psw =mysqli_real_escape_string($connect,$_REQUEST['psw']);



          $query="SELECT username,password
          FROM uiuexpresslogin 
          where username='$username' AND password ='$psw';";
          

      $result=mysqli_query($connect,$query);

      $mysql=mysqli_num_rows($result);

      if($mysql){
        if(isset($_POST['username'])){
          $username=$_POST['username'];
          $url="home.php?username=".$username;
        header('location: '.$url);
        }
      }
      else{
          header("location: type3.html?Login Cancel");
      }
      }
?>

<?php

$username=$_GET['username'];
echo $username;

if(isset($_POST['submit'])){
  
  $username=$_GET['username'];
  $url="uiu.php?username=".$username;
  header('location: '.$url);
}
   
   
      if(isset($_POST['submit2'])){
        $username=$_GET['username'];
      
        $url="jungleHome.php?username=".$username;
      header('location: '.$url);
      }
   
   



?>
